package medicine;

public class MedicineInfo {
	public void display(){
		System.out.println("Company :Care Hospital");
		System.out.println("Address :Bhubaneswar");
		}
	}
class Tablet extends MedicineInfo{
		 
		public void display(){
			System.out.println("store it in a cool and dry place");
			}
		}
class Syrup extends MedicineInfo{
	public void display(){
		System.out.println("it is very expensive");
		}
	}
class Ointment extends MedicineInfo{
	public void display(){
		System.out.println("for external use only");
		}
}
