package com;

public class Main_methods {
public void createBook_Class() {
	Book_Class b[] = new Book_Class[4];		 
    b[0] = new Book_Class("Java Programing", 350);
    b[1] = new Book_Class("C", 200);
    b[2] = new Book_Class("C++", 250);
    b[3] = new Book_Class("Python", 300);
    for(int i = 0; i<b.length; i++) {
	         b[i].display();
    }
}
public void showBooks() {
  	createBook_Class();
}
public static void main(String args[])  {
    Main_methods c1 = new Main_methods();  
	c1.showBooks();
   
      }
}
